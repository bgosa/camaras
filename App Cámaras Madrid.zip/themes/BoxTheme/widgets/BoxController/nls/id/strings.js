define({
  "_widgetLabel": "Pengontrol Kotak"
});