define({
  "_widgetLabel": "Box-controller"
});