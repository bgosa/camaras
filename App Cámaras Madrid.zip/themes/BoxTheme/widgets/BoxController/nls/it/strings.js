define({
  "_widgetLabel": "Controller riquadro"
});