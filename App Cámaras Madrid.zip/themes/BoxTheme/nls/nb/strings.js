define({
  "_themeLabel": "Boks-tema",
  "_layout_default": "Standardoppsett",
  "_layout_top": "Topp-oppsett"
});