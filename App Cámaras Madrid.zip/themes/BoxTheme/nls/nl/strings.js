define({
  "_themeLabel": "Boxthema",
  "_layout_default": "Standaardlay-out",
  "_layout_top": "Bovenste lay-out"
});